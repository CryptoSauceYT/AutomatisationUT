package io.sauce.tradingbot.domain.response;

import lombok.Data;

@Data
public class PlaceOrderResp {

    private String orderId;

    private String clientId;

}
